# ntripcaster
Simple NTRIPCaster example, using the NTRIP2.0 protocol
