#include <unistd.h> 
#include <fcntl.h> 
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h> 
#include <sys/epoll.h> 
#include <netinet/in.h> 
#include <arpa/inet.h> 
#include <netdb.h>

#include "util.h"

int main(void)
{
	int m_sock, s_sock;
	int ret;
	char recv_buf[1024] = {0};	

	struct sockaddr_in server_addr;
	memset(&server_addr, 0, sizeof(&server_addr));
	server_addr.sin_family = AF_INET;
#if 1
	server_addr.sin_port = htons(8090);
	//server_addr.sin_addr.s_addr = inet_addr("113.110.228.189");
	struct hostent *hptr = gethostbyname("r2151985rq.imwork.net");
	server_addr.sin_addr.s_addr = *((unsigned long*)hptr->h_addr_list[0]);;
#else
	server_addr.sin_port = htons(12345);
	server_addr.sin_addr.s_addr = inet_addr("192.168.1.105");
#endif

	struct sockaddr_in source_addr;
	memset(&source_addr, 0, sizeof(&source_addr));
	source_addr.sin_family = AF_INET;
#if 1
/*
	source_addr.sin_port = htons(1234);
	source_addr.sin_addr.s_addr = inet_addr("192.168.1.117");
*/
#else
	source_addr.sin_port = htons(1234);
	source_addr.sin_addr.s_addr = inet_addr("192.168.1.209");
#endif
	char send_buf[1024] = {
		"POST /RTCM32 HTTP/1.1\r\n"
		"Host: 192.168.1.105:12345\r\n"
		"Ntrip-Version: Ntrip/2.0\r\n"
		"User-Agent: NTRIP KleinNTRIPServer/20180918\r\n"
		"Authorization: Basic dGVzdDAxOnRlc3Rpbmc=\r\n"
		"Ntrip-STR: \r\n"
		"Connection: close\r\n"
		"Transfer-Encoding: chunked\r\n"
	};
	
	char data[16] = {0xd3, 0x00, 0x70, 0x8e, 0x43, 0x56, 0x45, 0x00, 0x00, 0x55, 0xfb, 0x89, 0xff, 0xff, '\r', '\n'};

	m_sock= socket(AF_INET, SOCK_STREAM, 0);
	if(m_sock == -1) {
		exit(1);
	}

	ret = connect(m_sock, (struct sockaddr *)&server_addr, sizeof(server_addr));
	if(ret < 0){
		printf("connect caster fail\n");
		exit(1);
	}

	printf("connect caster ok\n");

	s_sock= socket(AF_INET, SOCK_STREAM, 0);
	if(s_sock == -1) {
		exit(1);
	}
/*
	ret = connect(s_sock, (struct sockaddr *)&source_addr, sizeof(source_addr));
	if(ret < 0){
		printf("connect source fail\n");
		exit(1);
	}

	printf("connect source ok\n");

	ret = send(m_sock, send_buf, strlen(send_buf), 0);	
	if(ret < 0){
		exit(1);
	}

	cout << "send source ok" << endl;
*/
	while(1){
		ret = recv(m_sock, recv_buf, 1024, 0);
		if(ret > 0 && !strncmp(recv_buf, "ICY 200 OK\r\n", 12)){
			printf("connect caster ok \n");
			break;
		}
	}

	while(1){
#if 0
		memset(recv_buf, 0x0, 1024);
		ret = recv(s_sock, recv_buf, 1024, 0);
		if(ret > 0){
			ret = send(m_sock, recv_buf, ret, 0);
			if(ret > 0){
				//cout << "send data ok" << endl;
			}
		}
#else
		ret = send(m_sock, data, sizeof(data), 0);
		if(ret > 0){
			cout << "send data ok" << endl;
		}
		sleep(1);
#endif
	}

	close(m_sock);
//	close(s_sock);

	return 0;	
}

